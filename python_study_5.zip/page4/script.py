from food import Food
from drink import Drink

food1 = Food('Sandwich', 5)

# Set the calorie_count variable of food1 to 330
food1.calorie_count=330

# Call the calorie_info method from food1
food1.calorie_info()

