x = 10
# if x is greater than 30, print 'x is greater than 30'
if x>30:
    print('x is greater than 30')


money = 5
apple_price = 2
# if money is equal to or greater than apple_price, print 'You can buy an apple'
if money>=apple_price:
    print('You can buy an apple')

