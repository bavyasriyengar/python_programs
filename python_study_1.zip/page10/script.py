x = 7 * 10
y = 5 * 6

# if x equals 70, print 'x is 70'
if x==70:
    print('x is 70')

# if y does not equal 40, print 'y is not 40' 
if y!=40:
    print('y is not 40')