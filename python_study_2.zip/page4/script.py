fruits = ['apple', 'banana', 'orange']

# Get the elements of fruits using a for loop, and print 'I like ___s'
for fruit in fruits:
    print('I like '+ fruit +'s')