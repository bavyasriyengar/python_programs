fruits = {'apple': 'manzana', 'orange': 'naranja', 'grape': 'uva'}

# With a for loop, print '___ is ___ in Spanish'
for fruit_key in fruits:
    print(fruit_key + ' is '+ fruits[fruit_key]+ ' in Spanish')
